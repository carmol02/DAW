<?php
$dsn = 'mysql:host=mysql;dbname=usuari_nom;charset=utf8mb4';
$user = 'usuari';
$password = 'password';

try {
    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    $stmt = $pdo->query("SELECT * FROM proves_1234");
    echo "<h2>Registres de la base de dades</h2>";
    while ($row = $stmt->fetch()) {
        echo "<p>{$row['id']}: {$row['text']}</p>";
    }
} catch (PDOException $e) {
    echo "Error de connexió: " . $e->getMessage();
}
?>

