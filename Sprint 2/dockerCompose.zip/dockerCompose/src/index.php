<?php
// Dades de connexió
$host = 'db'; // nom del servei MySQL al docker-compose
$db   = 'db_proves';
$user = 'carles_proves';
$pass = 'carles_proves';
$charset = 'utf8mb4';

// DSN = Data Source Name
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    // Crear una connexió PDO
    $pdo = new PDO($dsn, $user, $pass);
    // Configurar PDO perquè llanci excepcions si hi ha errors
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta SQL
    $stmt = $pdo->query("SELECT * FROM proves_carles");

    echo "<h1>Llistat de registres</h1>";
    echo "<ul>";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<li>" . htmlspecialchars($row['text_prova']) . "</li>";
    }
    echo "</ul>";

} catch (PDOException $e) {
    echo "Error de connexió: " . $e->getMessage();
}
?>
